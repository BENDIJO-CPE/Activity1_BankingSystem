
package benduoa1.bankingsystem;

import java.util.Arrays;
import java.util.Scanner;


public class BENDUOA1BankingSystem {
    private static int balance = 0;
    private static int [] deposits = new int [1000];
    private static int arrDep = 0;
    
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        
        while (true) {
            System.out.println("\n---------MENU---------");
            System.out.println("[1] Deopsit Money");
            System.out.println("[2] Withdraw Money");
            System.out.println("[3] Check Balance");
            
            System.out.println("\nEnter your CHOICE: ");
            int input = scn.nextInt();
            
            if(input == 1){
                System.out.println("Enter amount to deposit:$");
                int amountDeposit = scn.nextInt();
                moneyDeposit(amountDeposit);
                previousDeposits(scn);
            }else if (input == 2 ) {
                System.out.println("Enter the amount to withdraw:$ ");
                int amountDraw = scn.nextInt();
                withdrawMoney(amountDraw);
            }else if (input == 3){
                showAscDep();
                scn.close();
                System.exit(0);
            }else { 
                System.out.println("INVALID CHOICE!!\nPlease Try Again\n");
            }
        }
    }
    private static void moneyDeposit (int amount){
        if (amount <= 0) {
            System.out.println("Plase deposit a right amount:");
        }else {
            deposits[arrDep++] = amount;
            balance += amount;
            System.out.println("\nYOu deposited:$" + amount + "\n");
        }
    }
    private static void withdrawMoney (int amount){
        if(amount != balance) {
            System.out.println("\nInvalid amountn\n");
        }else {
            balance -= amount;
            System.out.println("You withdrawn" + amount + "succesfully\n");
        }
    }
    private static void currentBal(){
        System.out.println("Your current balance:$" + balance);
    }
    private static void showAscDep() {
        if (arrDep == 0) {
            System.out.println();
        } else {
            int [] sortedDeposits = Arrays.copyOf(deposits, arrDep);
            Arrays.sort(sortedDeposits);

            System.out.println("\nYour sorted balance:");
            System.out.print("[");
            
            for (int i = 0; i < arrDep; i++) {
                System.out.print("$" + sortedDeposits[i]);
                if (i < arrDep - 1) {
                    System.out.print(",");
                }
            }
            System.out.println("]");
        }
    }
        private static void previousDeposits(Scanner scn) {
        if (arrDep > 0) {
            System.out.println("\nYour Previous Deposits:");
            System.out.print("[");
            for (int i = 0; i < arrDep; i++) {
                System.out.print("$" + deposits[i]);
                if (i < arrDep - 1) {
                    System.out.print(", ");
                }
            }
            System.out.println("]\n");
        }
        System.out.println("Do you want another deposit?\n PRESS\n [y] if YES\n [n] if NO");
        String anotherDepoChoice = scn.next();
        
        if (anotherDepoChoice.equals("y")) {
            System.out.println("Enter amount:$");
            int depositAmount = scn.nextInt();
            moneyDeposit(depositAmount);
            previousDeposits(scn);
        }
    }
}
